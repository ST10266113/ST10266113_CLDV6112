﻿namespace KhumaloCraftFinal.Views.Products
{
    public class Create
    {
    }
}
