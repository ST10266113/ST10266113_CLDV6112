﻿namespace KhumaloCraftFinal.Views.Products
{
    public class ProductList
    {
    }
}
