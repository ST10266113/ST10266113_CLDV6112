﻿namespace KhumaloCraftFinal.Views.Products
{
    public class Edit
    {
    }
}
