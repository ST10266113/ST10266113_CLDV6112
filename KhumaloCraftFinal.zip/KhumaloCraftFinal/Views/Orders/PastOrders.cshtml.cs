﻿namespace KhumaloCraftFinal.Views.Orders
{
    public class PastOrders
    {
    }
}
