﻿namespace KhumaloCraftFinal.Views.Orders
{
    public class AdminOrders
    {
    }
}
