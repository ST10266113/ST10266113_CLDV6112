﻿namespace KhumaloCraftFinal.Views.Orders
{
    public class Checkout
    {
    }
}
