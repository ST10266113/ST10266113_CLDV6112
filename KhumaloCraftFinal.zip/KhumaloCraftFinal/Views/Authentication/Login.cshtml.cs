﻿namespace KhumaloCraftFinal.Views.Authentication
{
    public class Login
    {
    }
}
