using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KhumaloCraftFinal.Views.Home
{
    public class About_usModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
