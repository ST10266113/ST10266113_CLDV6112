﻿using System.Collections.Generic; // Add this line

namespace KhumaloCraftFinal.Models.ViewModels
{
    public class OrderViewModel
    {
        public int OrderId { get; set; } // Change the type from string to int
        public List<Order> OrderItems { get; set; }
    }
}
