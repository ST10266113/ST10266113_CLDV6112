using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace KhumaloCraftFinal.Controllers
{
    
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult About()
        {
            return View();
        }

        public IActionResult Contact()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Contact(ContactFormModel model)
        {
            if (ModelState.IsValid)
            {
                // Process the model (e.g., send email, save to database)
                // For demonstration purposes, just redirect to a success page
                return RedirectToAction("ContactSuccess");
            }
            return View(model);
        }

        public IActionResult ContactSuccess()
        {
            return View();
        }
    }
}

// Model for the contact form data
public class ContactFormModel
    {
        [Required(ErrorMessage = "Name is required")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Phone number is required")]
        public string Phone { get; set; }

        [Required(ErrorMessage = "Location is required")]
        public string Location { get; set; }

        [Required(ErrorMessage = "Message is required")]
        public string Message { get; set; }
    }
